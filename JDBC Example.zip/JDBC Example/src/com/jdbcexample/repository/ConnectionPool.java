package com.jdbcexample.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionPool {
	
	private ConnectionPool() {}
	
	static {
		
		try {
			System.out.println("Retrieving JDBC Driver for MYSQL DB Connection");
			Class.forName("com.mysql.jdbc.Driver");
		} catch(ClassNotFoundException e) {
			System.out.println("Missing MYSQL JDBC Driver");
			e.printStackTrace();
		}
		
		System.out.println("MySQL JDBC Driver Successfully Registered!");
	}
	
	public static Connection getConnection() {
		Connection connection = null;
		
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bootcamptestdatabase", "root", "root");
		} catch(SQLException e) {
			System.out.println("Connection Failed!");
			e.printStackTrace();
		}
		
		if(connection != null) {
			System.out.println("Database connection established");
		} else {
			System.out.println("Database connection not available");
		}
		
		return connection;
	}
	
}

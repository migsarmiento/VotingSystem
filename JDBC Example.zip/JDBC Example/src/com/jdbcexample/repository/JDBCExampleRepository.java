package com.jdbcexample.repository;

public interface JDBCExampleRepository {

}

package com.jdbcexample.repository.impl;

public class JDBCExampleRepositoryImpl {

}

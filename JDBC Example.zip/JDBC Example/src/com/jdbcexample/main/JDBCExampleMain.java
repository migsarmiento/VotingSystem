package com.jdbcexample.main;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.jdbcexample.repository.ConnectionPool;

public class JDBCExampleMain {

	public static void main(String[] args) {

		
		
		Connection connection = ConnectionPool.getConnection();
		
		
		String dropTableQuery = "DROP TABLE USER";
		
		String createTableQuery = "CREATE TABLE USER("
				+ "USER_ID INT(5) NOT NULL, "
				+ "USERNAME VARCHAR(20) NOT NULL, "
				+ "CREATED_BY VARCHAR(20) NOT NULL, "
				+ "CREATED_DATE DATE NOT NULL, "
				+ "PRIMARY KEY(USER_ID) "
				+ ")";
		
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(dropTableQuery);
			System.out.println("User Table Deleted");
			statement.execute(createTableQuery);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println("User Table Created");
		
	}
	
}
